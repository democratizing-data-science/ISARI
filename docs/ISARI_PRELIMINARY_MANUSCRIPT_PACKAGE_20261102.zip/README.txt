Open report/ISARI_PRELIMINARY_ANALYTICAL_REPORT.docx for the polished illustrated report and interactive/00_dashboard.html for interactive visualizations.
